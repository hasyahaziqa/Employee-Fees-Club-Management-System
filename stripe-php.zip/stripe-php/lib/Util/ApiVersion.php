<?php

// File generated from our OpenAPI spec

namespace Stripe\Util;

class ApiVersion
{
    const CURRENT = '2022-11-15';
}
