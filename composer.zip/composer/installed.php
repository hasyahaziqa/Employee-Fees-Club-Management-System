<?php return array (
  'root' => 
  array (
    'pretty_version' => 'dev-master',
    'version' => 'dev-master',
    'aliases' => 
    array (
    ),
    'reference' => '88a069424a726b7e6d98eac5476a8bc7329d6f02',
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'aliases' => 
      array (
      ),
      'reference' => '88a069424a726b7e6d98eac5476a8bc7329d6f02',
    ),
    'stripe/stripe-php' => 
    array (
      'pretty_version' => 'v7.98.0',
      'version' => '7.98.0.0',
      'aliases' => 
      array (
      ),
      'reference' => '87f27d3da4a72c93da49d81011cb675c2847a7c0',
    ),
  ),
);