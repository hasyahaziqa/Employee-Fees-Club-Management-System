
<?php 
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<?php $page='grade';
include("dbconnect.php");

if(isset($_POST['save']))
{	 
	
	$sname = $_POST['sname'];
	$ic = $_POST['ic'];
	$emailid='';
	$joindate = '';
	$contact='';
	$about = '';
	$sector_code='';
	$grade='';
	$department='';
	
	$sname = mysqli_real_escape_string($link,$_POST['sname']);
	$ic = mysqli_real_escape_string($link,$_POST['ic']);
	$emailid = mysqli_real_escape_string($link,$_POST['emailid']);
	$joindate = mysqli_real_escape_string($link,$_POST['joindate']);
	$contact = mysqli_real_escape_string($link,$_POST['contact']);
	$about = mysqli_real_escape_string($link,$_POST['about']);
	$sector_code = mysqli_real_escape_string($link,$_POST['sector_code']);
	$grade = mysqli_real_escape_string($link,$_POST['grade']);
	$department = mysqli_real_escape_string($link,$_POST['department']);
	
	 $sql = "INSERT INTO student(sname,ic,emailid,joindate,contact,about,sector_code,grade,department)
	 VALUES ('$sname','$ic','$emailid','$joindate','$contact','$about','$sector_code','$grade','$department')";
	$sid = $link->insert_id;
	 if (mysqli_query($link, $sql)) {
		echo "<div class='alert alert-success'> <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Employee record has been added! </div>";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($link);
	 }
	 mysqli_close($link);
}


?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Employee Fees Collection System</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	
	<link href="css/ui.css" rel="stylesheet" />
	<link href="css/datepicker.css" rel="stylesheet" />	
	
    <script src="js/jquery-1.10.2.js"></script>
	
    <script type='text/javascript' src='js/jquery/jquery-ui-1.10.1.custom.min.js'></script>
   
	
</head>
<?php
include("header.php");
?>
<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
						<h1 class="page-head-line">Register Club </h1>
<!DOCTYPE html>
<html>
  <body>
	<form method="post" action="employeeinfo.php">
		
		<script type="text/javascript" src="js/validation/jquery.validate.min.js"></script>
                <div class="row">
				
                    <div class="col-sm-10 col-sm-offset-1">
               <div class="panel panel-success">
                        <div class="panel-heading">
							<h5>Add Employee Details</h5>
                        </div>
						<form action="employeeinfo.php" method="post" id="signupForm1" class="form-horizontal">
                        <div class="panel-body">
						<fieldset class="scheduler-border" >
						 <legend  class="scheduler-border">Personal Information:</legend>
						<div class="form-group">
								<label class="col-sm-2 control-label" for="Old">Full Name* </label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="sname" name="sname" />
								</div>
							
							
							</div><br>
						<div class="form-group">
								<label class="col-sm-2 control-label" for="Old">Identification Card </label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="ic" name="ic" maxlength="12" />
								</div>
							</div><br>
							
							
							<div class="form-group"><br>
								<label class="col-sm-2 control-label" for="Old">Contact* </label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="contact" name="contact" />
								</div>
							</div>
							<div class="form-group"><br>
								<label class="col-sm-2 control-label" for="Old">Sector Code* </label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="sector_code" name="sector_code" maxlength="20" />
								</div>
							</div>
							<div class="form-group"><br>
								<label class="col-sm-2 control-label" for="Old">Department Level* </label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="department" name="department" maxlength="50" />
								</div>
							</div>
							<div class="form-group"><br><br>
								<label class="col-sm-2 control-label" for="Old">Club* </label>
								<div class="col-sm-10">
									
									
								    <input type="hidden" name="grade" value="1">
									<select  class="form-control" id="grade" name="grade" >
										<option value="">Select club</option>
										
										<?php
									$sql = "select * from grade where delete_status='0' order by grade.grade asc";
									$q = $link->query($sql);
									
									while($r = $q->fetch_assoc())
									{
									echo '<option value="'.$r['id'].'"  '.(($grade==$r['id'])?'selected="selected"':'').'>'.$r['grade'].'</option>';
									}
									?>	
										</select> </select>  
                                    								
									
									
								</div>
						</div>
							<div class="form-group"><br>
								<label class="col-sm-2 control-label" for="Old">DOJ* </label>
								<div class="col-sm-10">
									<input type="date" class="form-control" placeholder="Date of Joining" id="joindate" name="joindate"  style="background-color: #fff;"  />
								</div>
							</div>
						 </fieldset>
							
						
						
							
							 <fieldset class="scheduler-border" >
						 <legend  class="scheduler-border">Optional Information:</legend>
							<div class="form-group">
								<label class="col-sm-2 control-label" for="Password">About Employee </label>
								<div class="col-sm-10">
	                        <textarea class="form-control" id="about" name="about"></textarea >
								</div>
							</div>
							
							<div class="form-group"><br><br>
								<label class="col-sm-2 control-label" for="Old">Email Id </label>
								<div class="col-sm-10">
									
									<input type="text" class="form-control" id="emailid" name="emailid"   />
								</div>
						    </div>
							</fieldset>
						
					
		<input type="submit" name="save" value="submit">
	</form>
  </body>
</html>